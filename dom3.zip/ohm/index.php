<?php
session_start();

    header("Location: ./../index.php");
    exit();

?>