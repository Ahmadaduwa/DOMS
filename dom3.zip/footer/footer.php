<footer id="footer-credit">
    <p id="footer-text">Copyright ©️ 2024 Teams IT SAB</p>
</footer>